#!/usr/bin/env python3
"""Apply Astra Local UI to pinned upstream llama.cpp Android example.

This lets our tiny repository build an actual llama.cpp-powered APK,
without vendoring a large and frequently updated C++ engine tree.
"""

from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
UPSTREAM = ROOT / "vendor" / "llama.cpp" / "examples" / "llama.android"
APP = UPSTREAM / "app"


def replace_exact(path: Path, before: str, after: str) -> None:
    source = path.read_text(encoding="utf-8")
    if before not in source:
        raise RuntimeError(f"Expected upstream content not found: {path}: {before!r}")
    path.write_text(source.replace(before, after, 1), encoding="utf-8")


if not (APP / "build.gradle.kts").is_file():
    raise RuntimeError("llama.cpp Android example not found; check the pinned clone step")

main_path = APP / "src" / "main" / "java" / "com" / "example" / "llama" / "MainActivity.kt"
if not main_path.is_file():
    raise RuntimeError("Upstream example's MainActivity path has changed")
shutil.copy2(ROOT / "app-overrides" / "MainActivity.kt", main_path)

replace_exact(
    APP / "build.gradle.kts",
    'applicationId = "com.example.llama.aichat"',
    'applicationId = "dev.astra.localai"',
)
manifest_path = APP / "src" / "main" / "AndroidManifest.xml"
replace_exact(manifest_path, 'android:allowBackup="true"', 'android:allowBackup="false"')
# Explicit fully qualified activity name: it remains correct after changing applicationId.
replace_exact(manifest_path, 'android:name=".MainActivity"', 'android:name="com.example.llama.MainActivity"')

strings_path = APP / "src" / "main" / "res" / "values" / "strings.xml"
strings = strings_path.read_text(encoding="utf-8")
strings, count = re.subn(
    r'(<string\s+name="app_name">)[^<]*(</string>)',
    r'\g<1>Astra Local\g<2>',
    strings,
    count=1,
)
if count != 1:
    raise RuntimeError("App title key not found in upstream strings.xml")
strings_path.write_text(strings, encoding="utf-8")

print("Applied Astra Local UI, private app ID and disabled backup.")
