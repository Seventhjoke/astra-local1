package com.example.llama

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Astra Local v0.1 — personal, offline GGUF chat for POCO F7 (arm64 / Android 16).
 *
 * The C++/JNI engine is taken from the pinned official llama.cpp Android example.
 * Only the Android presentation and model-import flow are customised here.
 *
 * Scope v0.1: single local model, in-session conversation, CPU inference.
 */
class MainActivity : AppCompatActivity() {

    private val background = Color.rgb(10, 14, 23)
    private val surface = Color.rgb(25, 33, 48)
    private val blue = Color.rgb(52, 111, 229)
    private val foreground = Color.rgb(237, 242, 250)
    private val secondary = Color.rgb(155, 174, 201)

    private lateinit var statusText: TextView
    private lateinit var modelText: TextView
    private lateinit var modelButton: Button
    private lateinit var sendButton: Button
    private lateinit var userInput: EditText
    private lateinit var messageScroll: ScrollView
    private lateinit var messageList: LinearLayout

    private lateinit var engine: InferenceEngine
    private var engineReady = false
    private var modelReady = false
    private var busy = false
    private var generationJob: Job? = null
    private var loadJob: Job? = null

    private val modelPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null && engineReady && !busy && !modelReady) {
            importAndLoad(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        buildUi()
        setStatus("Подготавливаю движок llama.cpp…")
        updateControls()

        lifecycleScope.launch {
            try {
                engine = withContext(Dispatchers.Default) {
                    AiChat.getInferenceEngine(applicationContext)
                }
                engineReady = true
                setStatus("Движок готов. Выбери модель GGUF.")
            } catch (e: Exception) {
                setStatus("Ошибка инициализации: ${e.message ?: e.javaClass.simpleName}")
            }
            updateControls()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val system = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(
                dp(16) + system.left,
                dp(14) + system.top,
                dp(16) + system.right,
                dp(14) + system.bottom
            )
            insets
        }
        setContentView(root)

        val title = TextView(this).apply {
            text = "ASTRA  LOCAL"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(foreground)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Локальная нейросеть · без облака"
            textSize = 13f
            setTextColor(secondary)
            setPadding(0, dp(4), 0, dp(16))
        }
        root.addView(subtitle)

        modelText = TextView(this).apply {
            text = "Модель не выбрана"
            setTextColor(foreground)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(modelText)

        statusText = TextView(this).apply {
            setTextColor(secondary)
            textSize = 13f
            setPadding(0, dp(6), 0, dp(10))
        }
        root.addView(statusText)

        modelButton = makeButton("Выбрать GGUF").apply {
            setOnClickListener { modelPicker.launch(arrayOf("*/*")) }
        }
        root.addView(modelButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        messageScroll = ScrollView(this).apply {
            fillViewport = true
            isVerticalScrollBarEnabled = false
        }
        messageList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        messageScroll.addView(messageList)
        root.addView(
            messageScroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        userInput = EditText(this).apply {
            hint = "Напиши сообщение…"
            setHintTextColor(secondary)
            setTextColor(foreground)
            textSize = 15f
            isSingleLine = false
            maxLines = 4
            minLines = 1
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(surface, 14)
        }
        composer.addView(userInput, LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        sendButton = makeButton("Отправить").apply {
            setOnClickListener { sendMessage() }
        }
        composer.addView(sendButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { leftMargin = dp(8) })
        root.addView(composer)

        val footer = TextView(this).apply {
            text = "V0.1 · GGUF · офлайн · только CPU"
            setTextColor(secondary)
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        root.addView(footer)
    }

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        backgroundTintList = ColorStateList.valueOf(blue)
        minHeight = dp(48)
    }

    private fun rounded(color: Int, cornerDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(cornerDp).toFloat()
        }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).roundToInt()

    private fun setStatus(status: String) {
        statusText.text = status
    }

    private fun updateControls() {
        modelButton.isEnabled = engineReady && !busy && !modelReady
        modelButton.text = if (modelReady) "Модель загружена" else "Выбрать GGUF"
        sendButton.isEnabled = modelReady && !busy
        userInput.isEnabled = modelReady && !busy
    }

    private fun importAndLoad(uri: Uri) {
        val fileName = getDisplayName(uri)
        if (!fileName.lowercase(Locale.ROOT).endsWith(".gguf")) {
            setStatus("Нужен файл модели с расширением .gguf")
            return
        }
        busy = true
        modelText.text = fileName
        setStatus("Копирую GGUF в хранилище приложения…")
        updateControls()

        loadJob = lifecycleScope.launch {
            try {
                val copiedFile = withContext(Dispatchers.IO) { copyModel(uri) }
                setStatus("Загружаю модель в оперативную память…")
                withContext(Dispatchers.Default) {
                    engine.loadModel(copiedFile.absolutePath)
                }
                modelReady = true
                setStatus("Модель готова. Можно общаться 🙂")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setStatus("Ошибка модели: ${e.message ?: e.javaClass.simpleName}")
                modelText.text = "Модель не загружена"
            } finally {
                busy = false
                updateControls()
            }
        }
    }

    /** Android's Storage Access Framework grants access to the selected file.
     *  llama.cpp needs a regular file path; we copy it ONCE to private storage.
     */
    private fun copyModel(uri: Uri): File {
        val dir = File(filesDir, "models")
        if (!dir.exists() && !dir.mkdirs()) {
            throw IOException("Не удалось создать каталог моделей")
        }
        val target = File(dir, "selected.gguf")
        val tmp = File.createTempFile("model-import-", ".tmp", dir)
        try {
            val stream = contentResolver.openInputStream(uri)
                ?: throw IOException("Не удалось открыть выбранный файл")
            stream.use { input ->
                val header = ByteArray(4)
                if (input.read(header) != 4 || !header.contentEquals(
                        byteArrayOf(0x47, 0x47, 0x55, 0x46)
                    )) {
                    throw IOException("Выбранный файл не имеет заголовка GGUF")
                }
                FileOutputStream(tmp).use { output ->
                    output.write(header)
                    input.copyTo(output, 1024 * 1024)
                    output.fd.sync()
                }
            }
            if (target.exists() && !target.delete()) {
                throw IOException("Не удалось заменить старый файл модели")
            }
            if (!tmp.renameTo(target)) {
                throw IOException("Не удалось сохранить GGUF")
            }
            return target
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    private fun getDisplayName(uri: Uri): String {
        contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
        )?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && cursor.moveToFirst()) {
                return cursor.getString(index) ?: "model.gguf"
            }
        }
        return "model.gguf"
    }

    private fun sendMessage() {
        if (!modelReady || busy) return
        val question = userInput.text.toString().trim()
        if (question.isEmpty()) return
        userInput.text.clear()
        appendMessage("Ты", question, fromUser = true)
        val assistantText = appendMessage("Модель", "…", fromUser = false)

        busy = true
        setStatus("Генерирую ответ…")
        updateControls()
        generationJob = lifecycleScope.launch(Dispatchers.Default) {
            val fullText = StringBuilder()
            try {
                engine.sendUserPrompt(question).collect { fragment ->
                    withContext(Dispatchers.Main) {
                        fullText.append(fragment)
                        assistantText.text = fullText.toString()
                        scrollToBottom()
                    }
                }
                withContext(Dispatchers.Main) { setStatus("Готова к следующему вопросу") }
            } catch (e: CancellationException) {
                withContext(NonCancellable + Dispatchers.Main) {
                    setStatus("Генерация остановлена")
                }
                throw e
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    assistantText.append("\n\nОшибка генерации: ${e.message ?: e.javaClass.simpleName}")
                    setStatus("Ошибка генерации")
                }
            } finally {
                withContext(NonCancellable + Dispatchers.Main) {
                    busy = false
                    updateControls()
                }
            }
        }
    }

    private fun appendMessage(name: String, content: String, fromUser: Boolean): TextView {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(if (fromUser) Color.rgb(31, 64, 124) else surface, 16)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        card.addView(TextView(this).apply {
            text = name
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(secondary)
            setPadding(0, 0, 0, dp(5))
        })
        val body = TextView(this).apply {
            text = content
            textSize = 16f
            setTextColor(foreground)
            setTextIsSelectable(true)
        }
        card.addView(body)
        messageList.addView(card, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) })
        scrollToBottom()
        return body
    }

    private fun scrollToBottom() {
        messageScroll.post { messageScroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onStop() {
        generationJob?.cancel()
        super.onStop()
    }

    override fun onDestroy() {
        generationJob?.cancel()
        loadJob?.cancel()
        if (::engine.isInitialized) engine.destroy()
        super.onDestroy()
    }
}
